package ar.org.centro8.curso.java.entities;

public class Auto extends Vehiculo {

    int Puertas;

    public Auto(String marca, String modelo, int puertas, Double precio) {
        super(marca, modelo, precio);
        Puertas = puertas;
    }

    @Override
    public String toString() {
        return "Auto [Puertas=" + Puertas + "]"+super.toString();
    }

    public int getPuertas() {
        return Puertas;
    }

    
    
    



}

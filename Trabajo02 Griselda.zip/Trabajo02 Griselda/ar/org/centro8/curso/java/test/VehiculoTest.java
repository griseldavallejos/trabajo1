package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.entities.Auto;
import ar.org.centro8.curso.java.entities.Moto;

public class VehiculoTest {

    public static void main(String[] args) {

        Auto A1 = new Auto("Peugeot", "206", 4, 200000.0);
        System.out.println(A1);
        System.out.println("\n");

        Moto M1 = new Moto("Honda", "Titan", 125, 60000.0);
        System.out.println(M1);
        System.out.println("\n");

        Auto A2 = new Auto("Peugeot", "208", 5, 250000.0);
        System.out.println(A2);
        System.out.println("\n");

        Moto M2 = new Moto("Yamaha", "YBR", 160, 80500.50);
        System.out.println(M2);
        System.out.println("\n");

    }

}

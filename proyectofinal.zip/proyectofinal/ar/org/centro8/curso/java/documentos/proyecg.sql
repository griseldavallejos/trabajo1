-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema proyectofinal
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema proyectofinal
-- -----------------------------------------------------
DROP schema IF EXISTS `proyectofinal`;

CREATE SCHEMA IF NOT EXISTS `proyectofinal` DEFAULT CHARACTER SET utf8 ;
USE `proyectofinal` ;

-- -----------------------------------------------------
-- Table `proyectofinal`.`Clientes`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `proyectofinal`.`Clientes` (
  `idCliente` INT NOT NULL,
  `Nombre` VARCHAR(45) NOT NULL,
  `Apellido` VARCHAR(45) NOT NULL,
  `Direccion` VARCHAR(45) NOT NULL,
  `Telefono` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idCliente`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `proyectofinal`.`Empleados`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `proyectofinal`.`Empleados` (
  `idEmpleados` INT NOT NULL,
  `Nombre` VARCHAR(45) NOT NULL,
  `Apellido` VARCHAR(45) NOT NULL,
  `Horario` DATE NOT NULL,
  PRIMARY KEY (`idEmpleados`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `proyectofinal`.`Facturas`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `proyectofinal`.`Facturas` (
  `Idfactura` INT NOT NULL AUTO_INCREMENT,
  `Idcliente` INT NOT NULL,
  `Fecha` DATE NOT NULL,
  `importe` DOUBLE NOT NULL,
  `IdEmpleado` INT NOT NULL,
  PRIMARY KEY (`Idfactura`),
  INDEX `IdClientes_idx` (`Idcliente` ASC),
  INDEX `IdEmpleados_idx` (`IdEmpleado` ASC),
  CONSTRAINT `IdClientes`
    FOREIGN KEY (`Idcliente`)
    REFERENCES `proyectofinal`.`Clientes` (`idCliente`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `IdEmpleados`
    FOREIGN KEY (`IdEmpleado`)
    REFERENCES `proyectofinal`.`Empleados` (`idEmpleados`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

package ar.org.centro8.curso.java.entities;

public class Vehiculo {
    private String color;
    private String marca;
    private String modelo;
    private Double precio;
    private Radio radio;

    public Vehiculo(String color, String marca, String modelo, double precio) {
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
    }
 

    public Vehiculo(String color, String marca, String modelo) {
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
    }

    public Vehiculo(String color, String marca, String modelo, Double precio, String marcaRadio) {
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
        this.radio = new Radio(marcaRadio);

    }

    

    public Vehiculo(String color, String marca, String modelo, Radio radio) {
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
        this.radio = radio;
    }


    @Override
    public String toString() {
        return "Vehiculo [color=" + color + ", marca=" + marca + ", modelo=" + modelo + ", precio=" + precio
                + ", radio=" + radio + "]";
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }

    public Radio getRadio() {
        return radio;
    }

    public void setRadio(Radio radio) {
        this.radio = radio;
    }
    

   
    
}



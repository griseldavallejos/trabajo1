package ar.org.centro8.curso.java.test;
import ar.org.centro8.curso.java.entities.AutoClasico;
import ar.org.centro8.curso.java.entities.AutoNuevo;


public class Vehiculo {
    public static void main(String[] args) {
        
        AutoClasico aC= new AutoClasico("Rojo","Fiat", "x2", 967000.0);
        System.out.println(aC);

        AutoNuevo aN=new AutoNuevo("gris", "fiat", "106", 1230000.0,"sony");
        System.out.println(aN);
    }
      
        
       
    }


